===================================================================
flCookie 0.1 (http://flcookie.flensed.com/)
--flCookie.js	(deploy)
--flCookie.swf: Flash v9.0.0 minimum	(deploy)
===================================================================
--flCookie.src.js	(source JS, commented)
--flCookie.min.js	(JS YUI compressed)
--flCookie-compile.bat: uses command-line 'mxmlc' (flex) compiler to compile flCookie.swf
--flCookie-compile.xml: configuration settings for 'mxmlc' compiler
--MainCOOKIE.as	(source AS3, main class file for flXHR.swf)
--CookiePolicyChecker.as	(source AS3, handles strict cross-domain policy file checking, 
			with both page-domain and swf-domain considered)
===================================================================