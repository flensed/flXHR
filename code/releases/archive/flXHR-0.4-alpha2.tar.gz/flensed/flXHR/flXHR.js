/*	flXHR 0.4 alpha2 <http://www.flxhr.com/>
	Copyright (c) 2008 Kyle Simpson
	This software is released under the MIT License <http://www.opensource.org/licenses/mit-license.php>

	====================================================================================================
	Portions of this code were extracted and/or derived from:

	SWFObject v2.1 beta7 <http://code.google.com/p/swfobject/>
	Copyright (c) 2007 Geoff Stearns, Michael Williams, and Bobby van der Sluis
	This software is released under the MIT License <http://www.opensource.org/licenses/mit-license.php>
*/

try { flensed_base_path.toLowerCase(); } catch(flXHR_err) { var flensed_base_path = ""; }

(function() {
	function load_script(src,type,language) {
		try {
			var scriptArry = document.getElementsByTagName('script');
			if ((typeof scriptArry !== "undefined") && (scriptArry !== null)) {
				for (var k in scriptArry) {
					if (scriptArry[k] !== Object.prototype[k]) { // Filter out prototype additions from other potential libraries
						try {
							if (typeof scriptArry[k].src !== "undefined") {
								if (scriptArry[k].src.indexOf(src) >= 0) { return; }  // script already loaded/loading...
							}
						}
						catch (err2) { }
					}
				}
			}
		}
		catch (err) { }

		var scriptElem = document.createElement('script');
		scriptElem.setAttribute("src",flensed_base_path+src);
		if (typeof type !== "undefined") { scriptElem.setAttribute("type",type); }
		if (typeof language !== "undefined") { scriptElem.setAttribute("language",language); }
		document.getElementsByTagName('head')[0].appendChild(scriptElem);
	}

	try { checkplayer.module_ready(); } catch (err5) {
		load_script("checkplayer.js","text/javascript");
	}
	load_script("flXHR.vbs","text/vbscript","vbscript");

	var appendInterval = null;
	(function appendToCore() {
		try { flensed.getObjectById("a"); } catch (err) {
			appendInterval = setTimeout(appendToCore,25);
			return;
		}

		flensed.binaryToString = function(binobj) {
			try { return flXHR_vb_BinaryToString(binobj); }
			catch (err) {
				var str = "";
				try { for (var i=0; i<binobj.length; i++) { str += String.fromCharCode(binobj[i]); } } catch (err2) { str += " "; }
				return str;
			}
		};
		flensed.arrayToBinary = function(byteArray) {
			var str = "";
			for (var i=0; i<byteArray.length; i++) {
				try { str += String.fromCharCode(byteArray[i]); } catch (err) { }
			}
			try { return flXHR_vb_StringToBinary(str); } catch (err2) { }
			return byteArray;
		};
	})();
})();


function flXHR(configObject) {
	if (typeof flXHR._id_counter === "undefined") { flXHR._id_counter = 0; }

	// Private Properties
	var	idNumber = ++flXHR._id_counter,
		constructQueue = [],
		constructInterval = null,
		notReadyInterval = null,
		timeoutInterval = null,
		swfId = null,
		readyState = -1,
		responseBody = null,
		responseText = null,
		responseXML = null,
		status = null,
		statusText = null,
		swfObj = null,
		UNDEF = "undefined",
		EMPTY = "",
		JSFUNC = "function",
		publicAPI = null,
		appendTo = null,

	// Configurable Properties (via instantiation constructor)
		instanceId = "flXHR_"+idNumber,
		binaryResponseBody = false,
		xmlResponseText = true,
		autoUpdatePlayer = false,
		swfIdPrefix = "flXHR_swf",
		styleClass = "flXHRhideSwf",
		appendToId = null,
		sendTimeout = -1,
		loadPolicyURL = null,
		onreadystatechange = null,
		onerror  = null,
		ontimeout = null;

	// Private Methods
	var constructor = function() {
		if (typeof configObject !== UNDEF && configObject !== null) {
			if ((typeof configObject.instanceId !== UNDEF) && (configObject.instanceId !== null) && (configObject.instanceId !== EMPTY)) { instanceId = configObject.instanceId; }
			if ((typeof configObject.swfIdPrefix !== UNDEF) && (configObject.swfIdPrefix !== null) && (configObject.swfIdPrefix !== EMPTY)) { swfIdPrefix = configObject.swfIdPrefix; }
			if ((typeof configObject.styleClass !== UNDEF) && (configObject.styleClass !== null) && (configObject.styleClass !== EMPTY)) { styleClass = configObject.styleClass; }
			if ((typeof configObject.appendToId !== UNDEF) && (configObject.appendToId !== null) && (configObject.appendToId !== EMPTY)) { appendToId = configObject.appendToId; }
			if ((typeof configObject.loadPolicyURL !== UNDEF) && (configObject.loadPolicyURL !== null) && (configObject.loadPolicyURL !== EMPTY)) { loadPolicyURL = configObject.loadPolicyURL; }

			if (typeof configObject.binaryResponseBody !== UNDEF) { binaryResponseBody = configObject.binaryResponseBody; }
			if (typeof configObject.xmlResponseText !== UNDEF) { xmlResponseText = configObject.xmlResponseText; }
			if (typeof configObject.autoUpdatePlayer !== UNDEF) { autoUpdatePlayer = configObject.autoUpdatePlayer; }
			if ((typeof configObject.sendTimeout !== UNDEF) && (parseInt(configObject.sendTimeout,10) > 0)) { sendTimeout = parseInt(configObject.sendTimeout,10); }

			if ((typeof configObject.onreadystatechange !== UNDEF) && (configObject.onreadystatechange !== null)) { onreadystatechange = configObject.onreadystatechange; }
			if ((typeof configObject.onerror !== UNDEF) && (configObject.onerror !== null)) { onerror = configObject.onerror; }
			if ((typeof configObject.ontimeout !== UNDEF) && (configObject.ontimeout !== null)) { ontimeout = configObject.ontimeout; }
		}

		swfId = swfIdPrefix+"_"+idNumber;

		(function waitForCore() {
			try { flensed.bindEvent(window,"onunload",cleanup_flXHR); }
			catch (err) {
				constructInterval = setTimeout(waitForCore,25);
				return;
			}
			constructInterval = setTimeout(continueConstructor,25);
		})();
	}();

	function continueConstructor() {
		if (appendToId === null) { appendTo = document.getElementsByTagName("body")[0]; }
		else { appendTo = flensed.getObjectById(appendToId); }

		if ((typeof appendTo === UNDEF) || (appendTo === null)) {
			constructInterval = setTimeout(continueConstructor,25);
			return;
		}
		try { swfobject.getObjectById("a"); } catch (err2) {
			constructInterval = setTimeout(continueConstructor,25);
			return;
		}
		try { checkplayer.module_ready(); } catch (err3) {
			constructInterval = setTimeout(continueConstructor,25);
			return;
		}

		if ((typeof flXHR._check_player === UNDEF) && (typeof checkplayer._instance === UNDEF)) {
			try {
				flXHR._check_player = new checkplayer(flXHR.MIN_PLAYER_VERSION,checkCallback,false,updateCallback);
			}
			catch (err4) { doError(flXHR.DEPENDENCY_ERROR,"flXHR: checkplayer Init Failed","The initialization of the 'checkplayer' library failed to complete."); return; }
		}
		else {
			flXHR._check_player = checkplayer._instance;
			stillContinueConstructor();
		}
	}

	function stillContinueConstructor() {
		try {
			swfobject.createCSS("."+styleClass,"width:1px;height:1px;position:absolute;visibility:hidden;");
		}
		catch (err) { doError(flXHR.DEPENDENCY_ERROR,"flXHR: swfobject Call Failed","A call to the 'swfobject' library failed to complete."); return; }

		var holder=document.createElement("div");
		holder.id = swfId;
		holder.className = styleClass;
		appendTo.appendChild(holder);
		appendTo = null;

		var flashvars = {};
		var params = { wmode:"transparent", allowScriptAccess:"always" };
		var attributes = { id:swfId, name:swfId, styleclass:this.styleClass };

		try {
			flXHR._check_player.DoSWF(flensed_base_path+"flXHR.swf", swfId, "1", "1", flashvars, params, attributes, finishConstructor);
		}
		catch (err2) { 
			doError(flXHR.DEPENDENCY_ERROR,"flXHR: checkplayer Call Failed","A call to the 'checkplayer' library failed to complete."); 
			return;
		}
	}

	function finishConstructor(loadStatus) {
		if (typeof loadStatus !== UNDEF) {
			if (loadStatus.status !== checkplayer.SWF_LOADED) { return; }
		}

		clearIntervals();
		swfObj = flensed.getObjectById(swfId);

		try { swfObj.reset(); }
		catch (err) {
			constructInterval = setTimeout(finishConstructor,25);
			return;
		}

		if (loadPolicyURL !== "") { swfObj.loadPolicy(loadPolicyURL); }
		swfObj.returnBinaryResponseBody(binaryResponseBody);
		swfObj.doOnReadyStateChange = doOnReadyStateChange;
		swfObj.doOnError = doOnError;
	
		readyState = 0;
		updateFromPublicAPI();
		updatePublicAPI();
		if (typeof onreadystatechange === JSFUNC) {
			try { onreadystatechange(publicAPI); } 
			catch (err2) { doError(flXHR.HANDLER_ERROR,"flXHR::onreadystatechange(): Error","An error occurred in the handler function. ("+err.message+")"); return; }
		}

		executeQueue();
	}

	function destructor() {
		if ((typeof swfObj !== UNDEF) && (swfObj !== null)) {
			try {
		 		clearIntervals();
				swfObj.abort();
			}
			catch(err) { }

			try { swfObj.doOnReadyStateChange = null; } catch(err2) { }
			try { swfObj.doOnError = null; } catch(err3) { }
			swfObj = null;
		
			try { swfobject.removeSWF(swfId); } catch(err4) { }
		}

		//constructQueue = null;
		onreadystatechange = null;
		onerror  = null;
		ontimeout = null;
		readyState = 0;
		status = null;
		statusText = null;
		responseText = null;
		responseXML = null;
		responseBody = null;

		try {
			for (var j in publicAPI) {
				if (publicAPI[j] !== Object.prototype[j]) {
					try { publicAPI[j] = null; } catch (err5) { }
				}
			}
		}
		catch (err6) { }
		publicAPI = null;
	}

	function cleanup_flXHR() {
		destructor();
		try {
			for (var k in flXHR) {
				if (flXHR[k] !== Object.prototype[k]) {
					try { flXHR[k] = null; } catch (err7) { }
				}
			}
		}
		catch (err8) { }
		if (typeof window.detachEvent !== UNDEF) { window.detachEvent("onunload",cleanup_flXHR); }
	}

	function doOnReadyStateChange() {
		if (typeof arguments[0] !== UNDEF) { readyState = arguments[0]; }
		if (readyState === 4) {
			clearIntervals();
			try { if ((binaryResponseBody) && (arguments[1] !== false) && (arguments[1].length > 0)) { responseBody = flensed.arrayToBinary(arguments[1]); } } catch (err) { }
			if ((typeof arguments[2] !== UNDEF) && (arguments[2] !== "")) {
				responseText = arguments[2];
				if (xmlResponseText) { 
					try { responseXML = flensed.parseXMLString(arguments[2]); }
					catch (err2) { responseXML = []; }	// why [] instead of {} ?
				}
			}
		}
		if (typeof arguments[3] !== UNDEF) { status = arguments[3]; }
		if (typeof arguments[4] !== UNDEF) { statusText = arguments[4]; }

		updateFromPublicAPI();
		updatePublicAPI();

		if (typeof onreadystatechange === JSFUNC) {
			try { onreadystatechange(publicAPI); } 
			catch (err3) { doError(flXHR.HANDLER_ERROR,"flXHR::onreadystatechange(): Error","An error occurred in the handler function. ("+err.message+")"); return; }
		}
	}

	function doOnError() {
		doError.apply({},arguments);
	}

	function doError() {
		clearIntervals();
		var errorObj;
		try {
			errorObj = new flensed.error(arguments[0],arguments[1],arguments[2],publicAPI);
		}
		catch (err) {
			function ErrorObjTemplate() { this.number=0;this.name="flXHR Error: Unknown";this.description="Unknown error from 'flXHR' library.";this.message=this.description;this.srcElement=publicAPI;var a=this.number,b=this.name,c=this.description;function toString() { return a+", "+b+", "+c; } this.toString=toString; }
			errorObj = new ErrorObjTemplate();
		}
		var handled = false;
		try { 
			if (typeof onerror === JSFUNC) { onerror(errorObj); handled = true; }
		}
		catch (err2) { 
			var prevError = errorObj.toString();
			function ErrorObjTemplate2() { this.number=flXHR.HANDLER_ERROR;this.name="flXHR::onerror(): Error";this.description="An error occured in the handler function. ("+err.message+")\nPrevious:["+prevError+"]";this.message=this.description;this.srcElement=publicAPI;var a=this.number,b=this.name,c=this.description;function toString() { return a+", "+b+", "+c; } this.toString=toString; }
			errorObj = new ErrorObjTemplate2();
		}
		if (!handled) {
			setTimeout(function() { flensed.throwUnhandledError(errorObj.toString()); },1);
		}
	}

	function doTimeout() {
		abort();	// calls clearIntervals()
		if (typeof ontimeout === JSFUNC) {
			try { ontimeout(publicAPI); }
			catch (err) {
				doError(flXHR.HANDLER_ERROR,"flXHR::ontimeout(): Error","An error occurred in the handler function. ("+err.message+")");
				return;
			}
		}
		else { doError(flXHR.TIMEOUT_ERROR,"flXHR: Operation Timed out","The requested operation timed out."); }
	}

	function clearIntervals() {
		clearTimeout(constructInterval);
		constructInterval = null;
		clearTimeout(timeoutInterval);
		timeoutInterval = null;
		clearTimeout(notReadyInterval);
		notReadyInterval = null;
	}


	function addToQueue(func,funcName,args) {
		constructQueue[constructQueue.length] = { func:func, funcName:funcName, args:args };
	}

	function executeQueue() {
		if (readyState < 0) {
			notReadyInterval = setTimeout(executeQueue,25);
			return;
		}
		var constructQueueLength = 0;
		try { constructQueueLength = constructQueue.length; } catch (err) { }
		for (var j=0; j<constructQueueLength; j++) {
			try {
				constructQueue[j].func.apply(publicAPI,constructQueue[j].args);
				constructQueue[j] = false;
			}
			catch (err2) {
				doError(flXHR.HANDLER_ERROR,"flXHR::"+constructQueue[j].funcName+"(): Error","An error occurred in the "+constructQueue[j].funcName+"() function."); 
				return;
			}
		}
		constructQueueQueue = null;
	}

	function updatePublicAPI() {
		try {
			publicAPI.readyState = readyState;
			publicAPI.status = status;
			publicAPI.statusText = statusText;
			publicAPI.responseText = responseText;
			publicAPI.responseXML = responseXML;
			publicAPI.responseBody = responseBody;
			publicAPI.onreadystatechange = onreadystatechange;
			publicAPI.onerror = onerror;
			publicAPI.ontimeout = ontimeout;
		}
		catch (err) { }
	}

	function updateFromPublicAPI() {
		try {
			sendTimeout = publicAPI.timeout;
			onreadystatechange = publicAPI.onreadystatechange;
			onerror = publicAPI.onerror;
			ontimeout = publicAPI.ontimeout;
		}
		catch (err) { }
	}

	function reset() {
		abort();
		readyState = 0;
		status = null;
		statusText = null;
		responseText = null;
		responseXML = null;
		responseBody = null;
		updatePublicAPI();
	}

	function checkCallback(checkObj) {
		if (checkObj.checkPassed) {
			stillContinueConstructor();
		}
		else if (!autoUpdatePlayer) {
			doError(flXHR.PLAYER_VERSION_ERROR,"flXHR: Insufficient Flash Player Version","The Flash Player was either not detected, or the detected version ("+checkObj.playerVersionDetected+") was not at least the minimum version ("+flXHR.MIN_PLAYER_VERSION+") needed by the 'flXHR' library.");
		}
		else {
			flXHR._check_player.UpdatePlayer();
		}
	}

	function updateCallback(checkObj) {
		if (checkObj.updateStatus === checkplayer.UPDATE_SUCCESSFUL) {
			try {
				window.open('','_self','');
				window.close();
				self.opener = window;
				self.close();
			}
			catch (err) { }
		}
		else if (checkObj.updateStatus === checkplayer.UPDATE_CANCELED) {
			doError(flXHR.PLAYER_VERSION_ERROR,"flXHR: Flash Player Update Canceled","The Flash Player was not updated.");
		}
		else if (checkObj.updateStatus === checkplayer.UPDATE_FAILED) {
			doError(flXHR.PLAYER_VERSION_ERROR,"flXHR: Flash Player Update Failed","The Flash Player was either not detected or could not be updated.");
		}
	}

	// Private Methods (XHR API functions)
	function abort() {
		clearIntervals();
		updateFromPublicAPI();
		try { swfObj.abort(); } 
		catch (err) { doError(flXHR.CALL_ERROR,"flXHR::abort(): Failed","The abort() call failed to complete."); }
	}

	function open() {
		updateFromPublicAPI();
		if (readyState < 0) {
			addToQueue(publicAPI.open,"open",arguments);
			return;
		}
		if (readyState > 0) { reset(); }
		try { swfObj.open(arguments[0],arguments[1],arguments[2],arguments[3],arguments[4]); } 
		catch (err) { doError(flXHR.CALL_ERROR,"flXHR::open(): Failed","The open() call failed to complete."); }
	}

	function send() {
		updateFromPublicAPI();
		if (readyState < 0) {
			addToQueue(publicAPI.send,"send",arguments);
			return;
		}
		if (sendTimeout > 0) { timeoutInterval = setTimeout(doTimeout,sendTimeout); }
		try { swfObj.send(arguments[0]); } 
		catch (err) { doError(flXHR.CALL_ERROR,"flXHR::send(): Failed","The send() call failed to complete."); }
	}

	function setRequestHeader() {
		updateFromPublicAPI();
		if (this.readyState < 0) {
			addToQueue(publicAPI.setRequestHeader,"setRequestHeader",arguments);
			return;
		}
		try { swfObj.setRequestHeader(arguments[0],arguments[1]); } 
		catch (err) { doError(flXHR.CALL_ERROR,"flXHR::setRequestHeader(): Failed","The setRequestHeader() call failed to complete."); }
	}

	function getRequestHeader() { updateFromPublicAPI(); return ""; }

	function getAllRequestHeaders() { updateFromPublicAPI(); return []; }	

	// Public API
	publicAPI = {
		// XHR API
		readyState:readyState,
		responseBody:responseBody,
		responseText:responseText,
		responseXML:responseXML,
		status:status,
		statusText:statusText,
		timeout:sendTimeout,
		open:open,
		send:send,
		abort:abort,
		setRequestHeader:setRequestHeader,
		getRequestHeader:getRequestHeader,
		getAllRequestHeaders:getAllRequestHeaders,
		onreadystatechange:onreadystatechange,
		ontimeout:ontimeout,

		// extended API
		instanceId:instanceId,
		onerror:onerror,
		Configure:function(configObj) {
			if (typeof configObj !== UNDEF && configObj !== null) {
				if ((typeof configObj.instanceId !== UNDEF) && (configObj.instanceId !== null) && (configObj.instanceId !== EMPTY)) { instanceId = configObj.instanceId; }
				if ((typeof configObj.onreadystatechange !== UNDEF) && (configObj.onreadystatechange !== null)) { onreadystatechange = configObj.onreadystatechange; }
				if ((typeof configObj.onerror !== UNDEF) && (configObj.onerror !== null)) { onerror = configObj.onerror; }
				if ((typeof configObj.ontimeout !== UNDEF) && (configObj.ontimeout !== null)) { ontimeout = configObj.ontimeout; }
				if ((typeof configObj.sendTimeout !== UNDEF) && (parseInt(configObj.sendTimeout,10) > 0)) { sendTimeout = parseInt(configObj.sendTimeout,10); }
				if ((typeof configObj.loadPolicyURL !== UNDEF) && (configObj.loadPolicyURL !== null) && (configObj.loadPolicyURL !== EMPTY)) { loadPolicyURL = configObj.loadPolicyURL; }
				updatePublicAPI();
			}
		},
		Reset:reset,
		Destroy:destructor
	};
	return publicAPI;
}

// Static Properties
flXHR.HANDLER_ERROR = 10;
flXHR.CALL_ERROR = 11;
flXHR.TIMEOUT_ERROR = 12;
flXHR.DEPENDENCY_ERROR = 13;
flXHR.PLAYER_VERSION_ERROR = 14;
flXHR.MIN_PLAYER_VERSION = "9.0.124";
flXHR.module_ready = function() {};