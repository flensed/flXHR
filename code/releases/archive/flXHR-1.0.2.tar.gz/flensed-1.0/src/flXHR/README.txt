===================================================================
flXHR 1.0.2 (http://flxhr.flensed.com/)
--flXHR.js	(deploy)
--flXHR.swf: Flash v9.0.124 minimum	(deploy)
--flXHR.vbs: for IE only, for binary emulation	(deploy)
===================================================================
--flXHR.src.js	(source JS, commented)
--flXHR.min.js	(JS YUI compressed)
--flXHR-compile.bat: uses command-line 'mxmlc' (flex) compiler to compile flXHR.swf
--flXHR-compile.xml: configuration settings for 'mxmlc' compiler
--Main.as	(source AS3, main class file for flXHR.swf)
--PolicyChecker.as	(source AS3, handles strict cross-domain policy file checking, 
			with both page-domain and swf-domain considered)
===================================================================