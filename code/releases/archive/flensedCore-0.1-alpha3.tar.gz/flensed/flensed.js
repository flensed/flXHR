/*	flensedCore 0.1 alpha3 <http://www.flensed.com/>
	Copyright (c) 2008 Kyle Simpson
	This software is released under the MIT License <http://www.opensource.org/licenses/mit-license.php>

	====================================================================================================
*/

if (typeof flensed === "undefined") { var flensed = new function() { }; }

flensed.parseXMLString = function(xmlStr) {
	var xmlDoc = null;
	if (window.ActiveXObject) {
		xmlDoc = new ActiveXObject("Microsoft.XMLDOM"); 
		xmlDoc.async=false;
		xmlDoc.loadXML(xmlStr);
	}
	else {
		var parser = new DOMParser();
		xmlDoc = parser.parseFromString(xmlStr,"text/xml");
	}
	return xmlDoc;
};
flensed.getObjectById = function(idStr) {
	try {
		if (document.layers) { return document.layers[idStr]; }
		else if (document.all) { return document.all[idStr]; }
		else if (document.getElementById) { return document.getElementById(idStr); }
	}
	catch (err) { }
	return null;
};
flensed.bindEvent = function(obj,eventName,handlerFunc) {
	eventName = eventName.toLowerCase();
	if (typeof obj.addEventListener !== "undefined") { obj.addEventListener(eventName.replace(/^on/,""),handlerFunc,false); }
	else if (typeof obj.attachEvent !== "undefined") { obj.attachEvent(eventName,handlerFunc); }
	else if (typeof obj[eventName] === "function") {
		var oldHandler = obj[eventName];
		obj[eventName] = function() {
			oldHandler();
			handlerFunc();
		};
	}
	else { obj[eventName] = handlerFunc; }
};
flensed.throwUnhandledError = function(errDescription) {
	throw new Error(errDescription);
};
flensed.error = function(code,name,description,srcElement) {
	return {
		number:code,
		name:name,
		description:description,
		message:description,
		srcElement:srcElement,
		toString:function() { return code+", "+name+", "+description; }
	};
};