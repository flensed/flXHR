===================================================================
flXHR 0.6 alpha1 (http://www.flXHR.com)
--flXHR.js
--flXHR.swf: Flash v9.0.124 minimum
--flXHR.vbs: for IE only, for binary emulation
===================================================================