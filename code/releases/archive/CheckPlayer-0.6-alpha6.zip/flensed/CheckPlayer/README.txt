===================================================================
CheckPlayer 0.6 alpha6 (http://checkplayer.flensed.com/)
--checkplayer.js
--updateplayer.swf: (1k) Flash v6.0.65 minimum
--sample.swf: (181k) Flash v1.0.0 minimum
	Background: Rainbow of Peace
	http://www.flickr.com/photos/jasohill/118616905/
	
	Jason Hill  (http://www.flickr.com/people/jasohill/)
	Iwate, Japan
===================================================================
SWFObject 2.1 beta7 (http://code.google.com/p/swfobject/)
--swfobject.js
===================================================================
