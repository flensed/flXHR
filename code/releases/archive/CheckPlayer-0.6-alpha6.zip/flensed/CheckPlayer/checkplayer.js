/*	CheckPlayer 0.6 alpha6 <http://checkplayer.flxhr.com/>
	Copyright (c) 2008 Kyle Simpson
	This software is released under the MIT License <http://www.opensource.org/licenses/mit-license.php>

	====================================================================================================
	Portions of this code were extracted and/or derived from:

	SWFObject v2.1 beta7 <http://code.google.com/p/swfobject/>
	Copyright (c) 2007 Geoff Stearns, Michael Williams, and Bobby van der Sluis
	This software is released under the MIT License <http://www.opensource.org/licenses/mit-license.php>
*/

(function() {
	var this_script = "checkplayer.js";		// DO NOT rename this file or change this line.
	var base_path_known = false;
	try { flensed_base_path.toLowerCase(); base_path_known = true; } catch(basepath_err) { window.flensed_base_path = ""; }
	function load_script(src,type,language) {
		try {
			var scriptArry = document.getElementsByTagName('script');
			var scriptfound = false;
			if ((typeof scriptArry !== "undefined") && (scriptArry !== null)) {
				for (var k in scriptArry) {
					if (scriptArry[k] !== Object.prototype[k]) { // Filter out prototype additions from other potential libraries
						try {
							if (typeof scriptArry[k].src !== "undefined") {
								if (!base_path_known && scriptArry[k].src.indexOf(this_script) >= 0) {
									base_path_known = true;
									window.flensed_base_path = scriptArry[k].src.substr(0,scriptArry[k].src.indexOf(this_script));
								}
								if (!scriptfound && scriptArry[k].src.indexOf(src) >= 0) { scriptfound = true; }  // script already loaded/loading...
							}
						}
						catch (err2) { }
					}
				}
			}
		}
		catch (err) { }
		if (scriptfound) { return; }
		
		var scriptElem = document.createElement('script');
		scriptElem.setAttribute("src",flensed_base_path+src);
		if (typeof type !== "undefined") { scriptElem.setAttribute("type",type); }
		if (typeof language !== "undefined") { scriptElem.setAttribute("language",language); }
		document.getElementsByTagName('head')[0].appendChild(scriptElem);
	}

	try { swfobject.getObjectById("a"); } catch (err3) {
		load_script("swfobject.js","text/javascript");
	}
	try { flensed.getObjectById("a"); } catch (err4) {
		load_script("flensed.js","text/javascript");
	}
})();

if (typeof flensed === "undefined") { var flensed = new function() { }; }

flensed.checkplayer = function(playerVersionCheck,checkCB,autoUpdate,updateCB) {
	if (typeof flensed.checkplayer._instance !== "undefined") { return flensed.checkplayer._instance; }

	// Private Properties
	var	MIN_XI_VERSION = "6.0.65",
	 	UNDEF = "undefined",
		EMPTY = "",
		OBJECT = "object",
		SHOCKWAVE_FLASH = "Shockwave Flash",
		SHOCKWAVE_FLASH_AX = "ShockwaveFlash.ShockwaveFlash",
		FLASH_MIME_TYPE = "application/x-shockwave-flash",
		JSFUNC = "function",
		JSSTR = "string",
		win = window,
		doc = document,
		nav = navigator,
		updateInterval = [],
		notReadyInterval = null,
		updateCalled = false,
		constructInterval = null,
		updateSWFId = null,
		updateContainerId = EMPTY,
		ready = false,
		updateObj = null,
		swfIdArr = [],
		swfIntArr = [],
		swfQueue = [],

	// Configurable Properties (via new() constructor)
		versionToCheck = null,
		checkCallback = null,
		updateCallback = null,
		updateFlash = false,

	// Properties Exposed (indirectly, read-only) in Public API
		flashVersionDetected = null,
		versionCheckPassed = false,
		updateable = false,
		updateStatus = false,
		holder = null;

	// Private Methods
	var ua = function() {
		var w3cdom = typeof doc.getElementById !== UNDEF && typeof doc.getElementsByTagName !== UNDEF && typeof doc.createElement !== UNDEF,
			playerVersion = [0,0,0],
			d = null;
		if (typeof nav.plugins !== UNDEF && typeof nav.plugins[SHOCKWAVE_FLASH] === OBJECT) {
			d = nav.plugins[SHOCKWAVE_FLASH].description;
			if (d && !(typeof nav.mimeTypes !== UNDEF && nav.mimeTypes[FLASH_MIME_TYPE] && !nav.mimeTypes[FLASH_MIME_TYPE].enabledPlugin)) { // navigator.mimeTypes["application/x-shockwave-flash"].enabledPlugin indicates whether plug-ins are enabled or disabled in Safari 3+
				d = d.replace(/^.*\s+(\S+\s+\S+$)/, "$1");
				playerVersion[0] = parseInt(d.replace(/^(.*)\..*$/, "$1"), 10);
				playerVersion[1] = parseInt(d.replace(/^.*\.(.*)\s.*$/, "$1"), 10);
				playerVersion[2] = /r/.test(d) ? parseInt(d.replace(/^.*r(.*)$/, "$1"), 10) : 0;
			}
		}
		else if (typeof win.ActiveXObject !== UNDEF) {
			var a = null, fp6Crash = false;
			try {
				a = new ActiveXObject(SHOCKWAVE_FLASH_AX + ".7");
			}
			catch(e) {
				try { 
					a = new ActiveXObject(SHOCKWAVE_FLASH_AX + ".6");
					playerVersion = [6,0,21];
					a.AllowScriptAccess = "always";  // Introduced in fp6.0.47
				}
				catch(e2) {
					if (playerVersion[0] === 6) {
						fp6Crash = true;
					}
				}
				if (!fp6Crash) {
					try {
						a = new ActiveXObject(SHOCKWAVE_FLASH_AX);
					}
					catch(e3) {}
				}
			}
			if (!fp6Crash && a) { // a will return null when ActiveX is disabled
				try {
					d = a.GetVariable("$version");  // Will crash fp6.0.21/23/29
					if (d) {
						d = d.split(" ")[1].split(",");
						playerVersion = [parseInt(d[0], 10), parseInt(d[1], 10), parseInt(d[2], 10)];
					}
				}
				catch(e4) {}
			}
		}
		var u = nav.userAgent.toLowerCase(),
			p = nav.platform.toLowerCase(),
			webkit = /webkit/.test(u) ? parseFloat(u.replace(/^.*webkit\/(\d+(\.\d+)?).*$/, "$1")) : false, // returns either the webkit version or false if not webkit
			ie = false,
			windows = p ? /win/.test(p) : /win/.test(u),
			mac = p ? /mac/.test(p) : /mac/.test(u);
		/*@cc_on
			ie = true;
			@if (@_win32)
				windows = true;
			@elif (@_mac)
				mac = true;
			@end
		@*/
		return { w3cdom:w3cdom, pv:playerVersion, webkit:webkit, ie:ie, win:windows, mac:mac };
	}();

	var constructor = function() {
		if ((typeof playerVersionCheck !== UNDEF) && (playerVersionCheck !== null) && (playerVersionCheck !== false)) { versionToCheck = playerVersionCheck + EMPTY; }	// convert to string
		else { versionToCheck = "0.0.0"; }
		if (typeof checkCB === JSFUNC) { checkCallback = checkCB; }
		if (typeof autoUpdate !== UNDEF) { updateFlash = !(!autoUpdate); }	// convert to boolean
		if (typeof updateCB === JSFUNC) { updateCallback = updateCB; }

		flashVersionDetected = ua.pv[0]+"."+ua.pv[1]+"."+ua.pv[2];

		(function waitForCore() {
			try { flensed.bindEvent(win,"onunload",destructor); }
			catch (err) {
				constructInterval = setTimeout(waitForCore,25);
				return;
			}
			constructInterval = setTimeout(continueConstructor,25);
		})();
	}();

	function continueConstructor() {
		var appendTo = doc.getElementsByTagName("body")[0];

		if ((typeof appendTo === UNDEF) || (appendTo === null)) {
			constructInterval = setTimeout(continueConstructor,25);
			return;
		}
		try { swfobject.getObjectById("a"); } catch (swfobject_err) {
			constructInterval = setTimeout(continueConstructor,25);
			return;
		}

		updateable = swfobject.hasFlashPlayerVersion(MIN_XI_VERSION);
		versionCheckPassed = swfobject.hasFlashPlayerVersion(versionToCheck);
		updatePublicAPI();

		ready = true;
		if (typeof checkCallback === JSFUNC) { checkCallback(publicAPI); }

		if (versionCheckPassed) { executeQueue(); }
		else if (updateFlash) { updateFlashPlayer(); }
	}

	function destructor() {
		if (typeof win.detachEvent !== UNDEF) { win.detachEvent("onunload",destructor); }
		if ((typeof updateObj !== UNDEF) && (updateObj !== null)) {
			try { updateObj.updateSWFCallback = null; } catch(err) { }
			updateObj = null;
		}
		for (var j in swfIdArr) {
			if (swfIdArr[j] !== Object.prototype[j]) {
				try { swfobject.removeSWF(j); } catch (err2) { }
			}
		}

		win = null;
		doc = null;
		nav = null;
		clearIntervals();
		swfQueue = null;
		checkCallback = null;
		updateCallback = null;

		for (var m in ua) {
			if (ua[m] !== Object.prototype[m]) {
				try { ua[m] = null; } catch (err3) { }
			}
		}
		ua = null;

		try {
			for (var k in publicAPI) {
				if (publicAPI[k] !== Object.prototype[k]) {
					try { publicAPI[k] = null; } catch (err4) { }
				}
			}
		}
		catch (err5) { }
		publicAPI = null;
		try {
			for (var n in flensed.checkplayer) {
				if (flensed.checkplayer[n] !== Object.prototype[n]) {
					try { flensed.checkplayer[n] = null; } catch (err6) { }
				}
			}
		}
		catch (err7) { }
	}

	function addToQueue(func,funcName,args) {
		swfQueue[swfQueue.length] = { func:func, funcName:funcName, args:args };
	}

	function executeQueue() {
		if (!ready) {
			notReadyInterval = setTimeout(executeQueue,25);
			return;
		}
		var swfQueueLength = 0;
		try { swfQueueLength = swfQueue.length; } catch (err) { }
		for (var j=0; j<swfQueueLength; j++) {
			try {
				swfQueue[j].func.apply(publicAPI,swfQueue[j].args);
				swfQueue[j] = false;
			}
			catch (err2) {
				versionCheckPassed = false;
				updatePublicAPI();

				if (typeof checkCallback === JSFUNC) { checkCallback(publicAPI); }
				else { throw new Error("checkplayer::"+swfQueue[j].funcName+"() call failed."); }
			}
		}
		swfQueue = null;
	}

	function clearIntervals() {
		clearTimeout(constructInterval);
		constructInterval = null;
		clearTimeout(notReadyInterval);
		notReadyInterval = null;
		for (var j in swfIntArr) {
			if (swfIntArr[j] !== Object.prototype[j]) {
				clearInterval(swfIntArr[j]);
				swfIntArr[j] = 0;
			}
		}
		for (var k in updateInterval) {
			if (updateInterval[k] !== Object.prototype[k]) {
				clearTimeout(updateInterval[k]);
				updateInterval[k] = 0;
			}
		}
	}

	function updatePublicAPI() {
		try {
			publicAPI.playerVersionDetected = flashVersionDetected;
			publicAPI.checkPassed = versionCheckPassed;
			publicAPI.updateable = updateable;
			publicAPI.updateStatus = updateStatus;
			publicAPI.updateControlsContainer = holder;
		}
		catch (err) { }
	}

	function setVisibility(id, isVisible) {
		var v = isVisible ? "visible" : "hidden";
		var obj = flensed.getObjectById(id);
		try {
			if (obj !== null && (typeof obj.style !== UNDEF) && (obj.style !== null)) { obj.style.visibility = v; }
			else { 
				try { swfobject.createCSS("#" + id, "visibility:" + v); } catch (err) { }
			}
		}
		catch (err2) { 
			try { swfobject.createCSS("#" + id, "visibility:" + v); } catch (err3) { }
		}
	}

	function updateFlashPlayer() {
		var appendTo = doc.getElementsByTagName("body")[0];

		if ((typeof appendTo === UNDEF) || (appendTo === null)) {
			updateInterval[updateInterval.length] = setTimeout(updateFlashPlayer,25);
			return;
		}
		try { var test = swfobject; } catch (swfobject_err) {
			updateInterval[updateInterval.length] = setTimeout(updateFlashPlayer,25);
			return;
		}
		
		if (!updateCalled) {
			updateCalled = true;
			clearIntervals();
			if (updateable) {
				updateContainerId = "CheckPlayerUpdate";
				updateSWFId = updateContainerId + "SWF";

				try {
					swfobject.createCSS("#"+updateContainerId,"width:315px;height:139px;position:absolute;left:5px;top:5px;border:1px solid #000000;background-color:#ffffff;text-align:center;display:block;padding-top:2px;");
					swfobject.createCSS("#"+updateSWFId,"display:inline");
				}
				catch (err) { updateFailed("A call to the 'swfobject' library failed."); return; }

				holder=doc.createElement("div");
				holder.id = updateContainerId;
				appendTo.appendChild(holder);
				setVisibility(holder.id,false);

				updatePublicAPI();

				var flashvars = { swfId:updateSWFId, MMredirectURL:win.location, MMplayerType:(ua.ie && ua.win ? "ActiveX" : "PlugIn"), MMdoctitle:doc.title.slice(0, 47) + " - Flash Player Installation" };
				var params = { allowScriptAccess:"always" };
				var attributes = { id:updateSWFId, name:updateSWFId };

				try {
					doSWF(flensed_base_path+"updateplayer.swf", {appendToId:updateContainerId}, "310", "137", flashvars, params, attributes, continueUpdate, true);
				}
				catch (err2) { updateFailed(); return; }
			}
			else { updateFailed(); }
		}
	}

	function updateFailed(errMsg) {
		if (typeof errMsg === UNDEF) { errMsg = "Flash Player not detected or not updateable."; }
		updateStatus = flensed.checkplayer.UPDATE_FAILED;
		updatePublicAPI();
		if (typeof updateCallback === JSFUNC) { updateCallback(publicAPI); }
		else {
			throw new Error("checkplayer::UpdatePlayer(): "+errMsg);
		}
	}

	function continueUpdate(loadStatus) {
		if (loadStatus.status === flensed.checkplayer.SWF_LOADED) {
			updateObj = loadStatus.srcElem;
			updateObj.updateSWFCallback = updateSWFCallback;

			updateStatus = flensed.checkplayer.UPDATE_INIT;
			updatePublicAPI();
			if (typeof updateCallback === JSFUNC) { updateCallback(publicAPI); }
			setVisibility(holder.id,true);
		}
		else if (loadStatus.status === flensed.checkplayer.SWF_FAILED) {
			updateFailed();
		}
	}

	function updateSWFCallback(statusCode) {
		try {
			if (statusCode === 0) {
				updateStatus = flensed.checkplayer.UPDATE_SUCCESSFUL;
				holder.style.display = "none";
			}
			else if (statusCode === 1) {
				updateStatus = flensed.checkplayer.UPDATE_CANCELED;
				holder.style.display = "none";
			}
			else if (statusCode === 2) {
				updateStatus = flensed.checkplayer.UPDATE_FAILED;
				holder.style.display = "none";
				updateFailed();
			}
		}
		catch (err) { }

		updatePublicAPI();

		if (typeof updateCallback === JSFUNC) { updateCallback(publicAPI); }
	}

	function doSWF(swfUrlStr, targetElem, widthStr, heightStr, flashvarsObj, parObj, attObj, swfCB, ignoreVersionCheck) {
		if (targetElem !== null && (typeof targetElem === JSSTR || typeof targetElem.replaceId === JSSTR)) { setVisibility(((typeof targetElem === JSSTR)?targetElem:targetElem.replaceId),false); }
		if (!ready) {
			addToQueue(doSWF,"DoSWF",arguments);
			return;
		}
		
		if (versionCheckPassed || ignoreVersionCheck) {
			widthStr += EMPTY; // Auto-convert to string to make it idiot proof
			heightStr += EMPTY;

			var att = (typeof attObj === OBJECT) ? attObj : {};
			att.data = swfUrlStr;
			att.width = widthStr;
			att.height = heightStr;
			var par = (typeof parObj === OBJECT) ? parObj : {};
			if (typeof flashvarsObj === OBJECT) {
				for (var i in flashvarsObj) {
					if (flashvarsObj[i] !== Object.prototype[i]) { // Filter out prototype additions from other potential libraries
						if (typeof par.flashvars !== UNDEF) {
							par.flashvars += "&" + i + "=" + flashvarsObj[i];
						}
						else {
							par.flashvars = i + "=" + flashvarsObj[i];
						}
					}
				}
			}

			if (typeof attObj.id !== UNDEF) { var swfId = attObj.id; }
			else if (targetElem !== null && (typeof targetElem === JSSTR || typeof targetElem.replaceId === JSSTR)) { var swfId = ((typeof targetElem === JSSTR)?targetElem:targetElem.replaceId); }
			else { var swfId = "swf_"+swfIdArr.length; }
			
			if (targetElem === null || targetElem === false || typeof targetElem.appendToId === JSSTR) {
				if (targetElem !== null && targetElem !== false && typeof targetElem.appendToId === JSSTR) { var appendTo = flensed.getObjectById(targetElem.appendToId); }
				else { var appendTo = doc.getElementsByTagName("body")[0]; }
				var targetObj = doc.createElement("div");
				var replaceId = targetObj.id = swfId;
				appendTo.appendChild(targetObj);
			}
			else { var replaceId = ((typeof targetElem.replaceId === JSSTR) ? targetElem.replaceId : targetElem); }

			if (typeof swfCB === JSFUNC) {
				var swfloading = function() {
					var theObj = flensed.getObjectById(swfId);
					if ((typeof theObj !== UNDEF) && (theObj !== null) && (theObj.nodeName === "OBJECT")) {
						var perloaded = 0;
						try { perloaded = theObj.PercentLoaded(); } catch (err) { }
						if (perloaded > 0) {
							if (perloaded < 100) {
								// prevent swfCB from blocking this interval call if the user-defined function is long running
								setTimeout(function(){swfCB({status:flensed.checkplayer.SWF_LOADING,srcId:swfId,srcElem:theObj});},1);
							}
							else {
								clearInterval(swfIntArr[swfId]);
								setVisibility(swfId,false);
								setVisibility(swfId,true);
								// prevent swfCB from blocking this interval call if the user-defined function is long running
								setTimeout(function(){swfCB({status:flensed.checkplayer.SWF_LOADED,srcId:swfId,srcElem:theObj});},1);
							}
						}
					}
				};
			}
			
			try { var srcelem = swfobject.createSWF(att, par, replaceId); }
			catch (err) { var srcelem = null; }
			
			if (srcelem !== null) {
				swfIdArr[swfIdArr.length] = swfId;
				if (typeof swfCB === JSFUNC) {
					swfCB({status:flensed.checkplayer.SWF_INIT,srcId:swfId,srcElem:srcelem});
					swfIntArr[swfId] = setInterval(swfloading,100);
				}
				if (swfId === replaceId) { setVisibility(swfId,true); }
			}
			else {
				if (typeof swfCB === JSFUNC) { swfCB({status:flensed.checkplayer.SWF_FAILED,srcId:swfId,srcElem:null}); }
				else { throw new Error("checkplayer::DoSWF(): SWF could not be loaded."); }
			}
		}
		else {
			if (typeof swfCB === JSFUNC) { swfCB({status:flensed.checkplayer.SWF_FAILED,srcId:swfId,srcElem:null}); }
			else { throw new Error("checkplayer::DoSWF(): Minimum Flash Version not detected."); }
		}
	}

	// Public API
	var publicAPI = {
		playerVersionDetected:flashVersionDetected,
		versionChecked:versionToCheck,
		checkPassed:versionCheckPassed,

		UpdatePlayer:updateFlashPlayer,
		DoSWF:function(swfUrlStr, targetElem, widthStr, heightStr, flashvarsObj, parObj, attObj, swfCB) {
			doSWF(swfUrlStr,targetElem,widthStr,heightStr,flashvarsObj,parObj,attObj,swfCB,false);
		},

		updateable:updateable,
		updateStatus:updateStatus,
		updateControlsContainer:holder
	};
	flensed.checkplayer._instance = publicAPI;
	return publicAPI;
}

flensed.checkplayer.UPDATE_INIT = 1;
flensed.checkplayer.UPDATE_SUCCESSFUL = 2;
flensed.checkplayer.UPDATE_CANCELED = 3;
flensed.checkplayer.UPDATE_FAILED = 4;
flensed.checkplayer.SWF_INIT = 5;
flensed.checkplayer.SWF_LOADING = 6;
flensed.checkplayer.SWF_LOADED = 7;
flensed.checkplayer.SWF_FAILED = 8;
flensed.checkplayer.module_ready = function() {};
