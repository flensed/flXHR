flensed Core 0.1 alpha1 (http://www.flensed.com)
--flensed.js
===================================================================
CheckPlayer 0.4 alpha2 (http://checkplayer.flxhr.com/)
--checkplayer.js
--updateplayer.swf: (1k) Flash v6.0.65 minimum
--sample.swf: (181k) Flash v1.0.0 minimum
	Background: Rainbow of Peace
	http://www.flickr.com/photos/jasohill/118616905/
	
	Jason Hill  (http://www.flickr.com/people/jasohill/)
	Iwate, Japan

===================================================================
flXHR 0.4 alpha2 (http://www.flXHR.com)
--flXHR.js
--flXHR.swf: Flash v9.0.124 minimum
--flXHR.vbs: for IE only, for binary emulation

===================================================================
SWFObject 2.1 beta7 (http://code.google.com/p/swfobject/)
--swfobject.js
