===================================================================
flXHR 1.0 rc1 (http://flxhr.flensed.com/)
--flXHR.js
--flXHR.swf: Flash v9.0.124 minimum
--flXHR.vbs: for IE only, for binary emulation
===================================================================
--flXHR-compile.bat: uses command-line 'mxmlc' (flex) compiler to compile flXHR.swf
--flXHR-config.xml: configuration settings for 'mxmlc' compile
--Main.as: main class file for flXHR.swf
--PolicyChecker.as: handles strict cross-domain policy file checking, with both page-domain and swf-domain considered
===================================================================