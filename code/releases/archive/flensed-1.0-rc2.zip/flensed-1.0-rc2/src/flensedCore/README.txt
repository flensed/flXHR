===================================================================
flensed Core 1.0 rc2 (http://www.flensed.com)
--flensed.src.js	(source JS, commented)
--flensed.min.js	(JS YUI compressed)
--flensed.js		(deploy)
===================================================================
