===================================================================
flXHR 0.5 alpha3 (http://www.flXHR.com)
--flXHR.js
--flXHR.swf: Flash v9.0.124 minimum
--flXHR.vbs: for IE only, for binary emulation
===================================================================