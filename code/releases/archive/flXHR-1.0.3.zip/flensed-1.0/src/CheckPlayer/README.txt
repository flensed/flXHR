===================================================================
CheckPlayer 1.0.1 (http://checkplayer.flensed.com/)
--checkplayer.js	(deploy)
--updateplayer.swf: 	(deploy)
===================================================================
SWFObject 2.1 (http://code.google.com/p/swfobject/)	(deploy)
--swfobject.js
===================================================================
--checkplayer.src.js	(source JS, commented)
--checkplayer.min.js	(JS YUI compressed)
--updateplayer.as	(source AS1, Flash IDE/MMC only)
--compile-updateplayer.bat: uses command-line 'mtasc' compiler to compile updateplayer.swf
--updateplayerMTASC.as	(source AS2, 'mtasc' compiler only)
===================================================================
--sample.swf: (181k) Flash v1.0.0 minimum
	Background: Rainbow of Peace
	http://www.flickr.com/photos/jasohill/118616905/
	
	Jason Hill  (http://www.flickr.com/people/jasohill/)
	Iwate, Japan
--sample2.swf: (191k) Flash v9.0.0 minimum (ExternalInterface)
	Background: Rainbow of Peace
	http://www.flickr.com/photos/jasohill/118616905/
	
	Jason Hill  (http://www.flickr.com/people/jasohill/)
	Iwate, Japan
===================================================================
