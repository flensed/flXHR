/*	flXHR 0.3 alpha1 <http://www.flxhr.com/>
	Copyright (c) 2008 Kyle Simpson
	This software is released under the MIT License <http://www.opensource.org/licenses/mit-license.php>

	====================================================================================================
	Portions of this code were extracted and/or derived from:

	SWFObject v2.1 beta6 <http://code.google.com/p/swfobject/>
	Copyright (c) 2007 Geoff Stearns, Michael Williams, and Bobby van der Sluis
	This software is released under the MIT License <http://www.opensource.org/licenses/mit-license.php>
*/


if (typeof(flXHR_base_path) == "undefined") var flXHR_base_path = "";
if (typeof(checkplayer_base_path) == "undefined") var checkplayer_base_path = flXHR_base_path;

(function() {
	function __load_script(src,type,language) {
		try {
			var scriptArry = document.getElementsByTagName('script');
			if ((typeof(scriptArry) != "undefined") && (scriptArry != null)) {
				for (var k in scriptArry) {
					try {
						if (typeof(scriptArry[k].src) != "undefined") {
							if (scriptArry[k].src.indexOf(src) >= 0) return;  // script already loaded/loading...
						}
					}
					catch (err2) { }
				}
			}
		}
		catch (err) { }

		var scriptElem = document.createElement('script');
		scriptElem.setAttribute("src",flXHR_base_path+src);
		if (typeof(type) != "undefined") scriptElem.setAttribute("type",type);
		if (typeof(language) != "undefined") scriptElem.setAttribute("language",language);
		document.getElementsByTagName('head')[0].appendChild(scriptElem);
	}

	if (typeof(swfobject) == "undefined") __load_script("swfobject.js","text/javascript");
	if (typeof(checkplayer) == "undefined") __load_script("checkplayer.js","text/javascript");
	__load_script("flXHR.vbs","text/vbscript","vbscript");
})();


function flXHR(configObject) {
	if (typeof(flXHR._id_counter) == "undefined") flXHR._id_counter = 0;

	// Private Properties
	var	 idNumber = ++flXHR._id_counter
		,constructQueue = new Array()
		,constructInterval = null
		,notReadyInterval = null
		,timeoutInterval = null
		,swfId = null
		,readyState = -1
		,responseBody = null
		,responseText = null
		,responseXML = null
		,status = null
		,statusText = null
		,swfObj = null
		,UNDEF = "undefined"
		,EMPTY = ""
		,JSFUNC = "function"
		,publicAPI = null
		,appendTo = null

	// Configurable Properties (via new() constructor)
		,instanceId = "flXHR_"+idNumber
		,binaryResponseBody = false
		,xmlResponseText = true
		,autoUpdatePlayer = false
		,swfIdPrefix = "flXHR_swf"
		,swfPath = flXHR_base_path+"flXHR.swf"
		,styleClass = "flXHRhideSwf"
		,appendToId = null
		,sendTimeout = -1
		,loadPolicyURL = null
		,onreadystatechange = null
		,onerror  = null
		,ontimeout = null
	;

	// Private Methods
	var _Constructor = (function() {
		if (typeof(configObject) != UNDEF && configObject != null) {
			if ((configObject.instanceId != null) && (configObject.instanceId != EMPTY)) instanceId = configObject.instanceId;
			if ((configObject.swfIdPrefix != null) && (configObject.swfIdPrefix != EMPTY)) swfIdPrefix = configObject.swfIdPrefix;
			if ((configObject.swfPath != null) && (configObject.swfPath != EMPTY)) swfPath = configObject.swfPath;
			if ((configObject.styleClass != null) && (configObject.styleClass != EMPTY)) styleClass = configObject.styleClass;
			if ((configObject.appendToId != null) && (configObject.appendToId != EMPTY)) appendToId = configObject.appendToId;
			if ((configObject.loadPolicyURL != null) && (configObject.loadPolicyURL != EMPTY)) loadPolicyURL = configObject.loadPolicyURL;

			if (typeof(configObject.binaryResponseBody) != UNDEF) binaryResponseBody = configObject.binaryResponseBody;
			if (typeof(configObject.xmlResponseText) != UNDEF) xmlResponseText = configObject.xmlResponseText;
			if (typeof(configObject.autoUpdatePlayer) != UNDEF) autoUpdatePlayer = configObject.autoUpdatePlayer;
			if ((typeof(configObject.sendTimeout) != UNDEF) && (parseInt(configObject.sendTimeout) > 0)) sendTimeout = parseInt(configObject.sendTimeout);

			if (configObject.onreadystatechange != null) onreadystatechange = configObject.onreadystatechange;
			if (configObject.onerror != null) onerror = configObject.onerror;
			if (configObject.ontimeout != null) ontimeout = configObject.ontimeout;
		}

		swfId = swfIdPrefix+"_"+idNumber;

		flXHR.BindEvent(window,"onunload",_Cleanup_flXHR);
		constructInterval = setTimeout(ContinueConstructor,25);
	})();


	function ContinueConstructor() {
		if (appendToId == null) appendTo = document.getElementsByTagName("body")[0];
		else appendTo = flXHR.GetObjectById(appendToId);

		if ((typeof(appendTo) == UNDEF) || (appendTo == null) || (typeof(swfobject) == UNDEF) || (typeof(checkplayer) == UNDEF)) {
			constructInterval = setTimeout(ContinueConstructor,25);
			return;
		}

		if ((typeof(flXHR._check_player) == UNDEF) && (typeof(checkplayer._instance) == UNDEF)) {
			try {
				flXHR._check_player = new checkplayer(flXHR.MIN_PLAYER_VERSION,CheckCallback,false,UpdateCallback);
			}
			catch (err) { DoError(flXHR.DEPENDENCY_ERROR,"flXHR: checkplayer Init Failed","The initialization of the 'checkplayer' library failed to complete."); return; }
		}
		else {
			flXHR._check_player = checkplayer._instance;
			StillContinueConstructor();
		}
	}

	function StillContinueConstructor() {
		try {
			swfobject.createCSS("."+styleClass,"width:1px;height:1px;position:absolute;visibility:hidden;");
		}
		catch (err) { DoError(flXHR.DEPENDENCY_ERROR,"flXHR: swfobject Call Failed","A call to the 'swfobject' library failed to complete."); return; }

		var holder=document.createElement("div");
		holder.id = swfId;
		holder.className = styleClass;
		appendTo.appendChild(holder);
		appendTo = null;

		var flashvars = {};
		var params = { wmode:"transparent", allowScriptAccess:"always" };
		var attributes = { id:swfId, name:swfId, styleclass:this.styleClass };

		try {
			flXHR._check_player.DoSWF(swfPath, swfId, "1", "1", flashvars, params, attributes, FinishConstructor);
		}
		catch (err) { 
			DoError(flXHR.DEPENDENCY_ERROR,"flXHR: checkplayer Call Failed","A call to the 'checkplayer' library failed to complete."); 
			return;
		}
	}

	function FinishConstructor(loadStatus) {
		if (typeof(loadStatus) != UNDEF) {
			if (loadStatus.status != checkplayer.SWF_LOADED) return;
		}

		ClearIntervals();
		swfObj = flXHR.GetObjectById(swfId);

		try { swfObj.reset(); }
		catch (err) {
			constructInterval = setTimeout(FinishConstructor,25);
			return;
		}

		if (loadPolicyURL != "") swfObj.loadPolicy(loadPolicyURL);
		swfObj.returnBinaryResponseBody(binaryResponseBody);
		swfObj.DoOnReadyStateChange = DoOnReadyStateChange;
		swfObj.DoOnError = DoOnError;
	
		readyState = 0;
		UpdateFromPublicAPI();
		UpdatePublicAPI();
		if (typeof(onreadystatechange) == JSFUNC) {
			try { onreadystatechange(publicAPI); } 
			catch (err) { DoError(flXHR.HANDLER_ERROR,"flXHR::onreadystatechange(): Error","An error occurred in the handler function. ("+err.message+")"); return; }
		}

		ExecuteQueue();
	}

	function _Destructor() {
		if ((typeof(swfObj) != UNDEF) && (swfObj != null)) {
			try {
		 		ClearIntervals();
				swfObj.abort();
			}
			catch(err) { }

			try { swfObj.DoOnReadyStateChange = null; } catch(err) { }
			try { swfObj.DoOnError = null; } catch(err) { }
			swfObj = null;
		
			try { swfobject.removeSWF(swfId); } catch(err) { }
		}

		//constructQueue = null;
		onreadystatechange = null;
		onerror  = null;
		ontimeout = null;
		readyState = 0;
		status = null;
		statusText = null;
		responseText = null;
		responseXML = null;
		responseBody = null;

		try {
			for (var j in publicAPI) {
				try { publicAPI[j] = null; } catch (err2) { }
			}
		}
		catch (err) { }
		publicAPI = null;
	}

	function _Cleanup_flXHR() {
		_Destructor();
		try {
			for (var k in flXHR) {
				try { flXHR[k] = null; } catch (err) { }
			}
		}
		catch (err) { }
		if (typeof(window.detachEvent) != UNDEF) window.detachEvent("onunload",_Cleanup_flXHR);
	}

	function DoOnReadyStateChange() {
		if (typeof(arguments[0]) != UNDEF) readyState = arguments[0];
		if (readyState == 4) {
			ClearIntervals();
			try { if ((binaryResponseBody) && (arguments[1] != false) && (arguments[1].length > 0)) responseBody = flXHR.ArrayToBinary(arguments[1]); } catch (err) { }
			if ((typeof(arguments[2]) != UNDEF) && (arguments[2] != "")) {
				responseText = arguments[2];
				if (xmlResponseText) { 
					try { responseXML = flXHR.ParseXMLString(arguments[2]); }
					catch (err) { responseXML = []; }	// why [] instead of {} ?
				}
			}
		}
		if (typeof(arguments[3]) != UNDEF) status = arguments[3];
		if (typeof(arguments[4]) != UNDEF) statusText = arguments[4];

		UpdateFromPublicAPI();
		UpdatePublicAPI();
		if (typeof(onreadystatechange) == JSFUNC) {
			try { onreadystatechange(publicAPI); } 
			catch (err) { DoError(flXHR.HANDLER_ERROR,"flXHR::onreadystatechange(): Error","An error occurred in the handler function. ("+err.message+")"); return; }
		}
	}

	function DoOnError() {
		DoError.apply({},arguments);
	}

	function DoError() {
		ClearIntervals();
		try {
			var errorObj = new flXHR.Error(arguments[0],arguments[1],arguments[2],publicAPI);
		}
		catch (err) {
			var errorObj = new function() { this.number=0;this.name="flXHR Error: Unknown";this.description="Unknown error from 'flXHR' library.";this.message=this.description;this.srcElement=publicAPI;this.toString=function() { return this.number+", "+this.name+", "+this.description; } };
		}
		var handled = false;
		try { 
			if (typeof(onerror) == JSFUNC) { onerror(errorObj); handled = true; }
		}
		catch (err) { 
			var prevError = errorObj.toString();
			errorObj = new function() { this.number=flXHR.HANDLER_ERROR;this.name="flXHR::onerror(): Error";this.description="An error occured in the handler function. ("+err.message+")\nPrevious:["+prevError+"]";this.message=this.description;this.srcElement=publicAPI;this.toString=function() { return this.number+", "+this.name+", "+this.description; } };
		}
		if (!handled) {
			setTimeout(function() { flXHR.ThrowUnhandledError(errorObj.toString()); },1);
		}
	}

	function DoTimeout() {
		abort();	// calls ClearIntervals()
		if (typeof(ontimeout) == JSFUNC) {
			try { ontimeout(publicAPI); }
			catch (err) {
				DoError(flXHR.HANDLER_ERROR,"flXHR::ontimeout(): Error","An error occurred in the handler function. ("+err.message+")");
				return;
			}
		}
		else DoError(flXHR.TIMEOUT_ERROR,"flXHR: Operation Timed out","The requested operation timed out.");
	}

	function ClearIntervals() {
		clearTimeout(constructInterval);
		constructInterval = null;
		clearTimeout(timeoutInterval);
		timeoutInterval = null;
		clearTimeout(notReadyInterval);
		notReadyInterval = null;
	}

	function AddToQueue(func,args) {
		constructQueue[constructQueue.length] = { func:func, args:args };
	}

	function ExecuteQueue() {
		if (readyState < 0) {
			notReadyInterval = setTimeout(ExecuteQueue,25);
			return;
		}
		var constructQueueLength = 0;
		try { constructQueueLength = constructQueue.length; } catch (err) { }
		for (var j=0; j<constructQueueLength; j++) {
			constructQueue[j].func.apply(publicAPI,constructQueue[j].args);
			constructQueue[j] = false;
		}
		constructQueue = null;
	}

	function UpdatePublicAPI() {
		try {
			publicAPI.readyState = readyState;
			publicAPI.status = status;
			publicAPI.statusText = statusText;
			publicAPI.responseText = responseText;
			publicAPI.responseXML = responseXML;
			publicAPI.responseBody = responseBody;
			publicAPI.onreadystatechange = onreadystatechange;
			publicAPI.onerror = onerror;
			publicAPI.ontimeout = ontimeout;
		}
		catch (err) { }
	}

	function UpdateFromPublicAPI() {
		try {
			sendTimeout = publicAPI.timeout;
			onreadystatechange = publicAPI.onreadystatechange;
			onerror = publicAPI.onerror;
			ontimeout = publicAPI.ontimeout;
		}
		catch (err) { }
	}

	function Reset() {
		abort();
		readyState = 0;
		status = null;
		statusText = null;
		responseText = null;
		responseXML = null;
		responseBody = null;
		UpdatePublicAPI();
	}

	function CheckCallback(checkObj) {
		if (checkObj.checkPassed) {
			StillContinueConstructor();
		}
		else if (!autoUpdatePlayer) {
			DoError(flXHR.PLAYER_VERSION_ERROR,"flXHR: Insufficient Flash Player Version","The Flash Player was either not detected, or the detected version ("+checkObj.playerVersionDetected+") was not at least the minimum version ("+flXHR.MIN_PLAYER_VERSION+") needed by the 'flXHR' library.");
		}
		else {
			flXHR._check_player.UpdatePlayer();
		}
	}

	function UpdateCallback(checkObj) {
		if (checkObj.updateStatus == checkplayer.UPDATE_SUCCESSFUL) {
			try {
				window.open('','_self','');
				window.close();
				self.opener = window;
				self.close();
			}
			catch (err) { }
		}
		else if (checkObj.updateStatus == checkplayer.UPDATE_CANCELED) {
			DoError(flXHR.PLAYER_VERSION_ERROR,"flXHR: Flash Player Update Canceled","The Flash Player was not updated.");
		}
		else if (checkObj.updateStatus == checkplayer.UPDATE_FAILED) {
			DoError(flXHR.PLAYER_VERSION_ERROR,"flXHR: Flash Player Update Failed","The Flash Player was either not detected or could not be updated.");
		}
	}

	// Private Methods (XHR API functions)
	function abort() {
		ClearIntervals();
		UpdateFromPublicAPI();
		try { swfObj.abort(); } 
		catch (err) { DoError(flXHR.CALL_ERROR,"flXHR::abort(): Failed","The abort() call failed to complete."); }
	}

	function open() {
		UpdateFromPublicAPI();
		if (readyState < 0) {
			AddToQueue(publicAPI.open,arguments);
			return;
		}
		if (readyState > 0) Reset();
		try { swfObj.open(arguments[0],arguments[1],arguments[2],arguments[3],arguments[4]); } 
		catch (err) { DoError(flXHR.CALL_ERROR,"flXHR::open(): Failed","The open() call failed to complete."); }
	}

	function send() {
		UpdateFromPublicAPI();
		if (readyState < 0) {
			AddToQueue(publicAPI.send,arguments);
			return;
		}
		if (sendTimeout > 0) timeoutInterval = setTimeout(DoTimeout,sendTimeout);
		try { swfObj.send(arguments[0]); } 
		catch (err) { DoError(flXHR.CALL_ERROR,"flXHR::send(): Failed","The send() call failed to complete."); }
	}

	function setRequestHeader() {
		UpdateFromPublicAPI();
		if (this.readyState < 0) {
			AddToQueue(publicAPI.setRequestHeader,arguments);
			return;
		}
		try { swfObj.setRequestHeader(arguments[0],arguments[1]); } 
		catch (err) { DoError(flXHR.CALL_ERROR,"flXHR::setRequestHeader(): Failed","The setRequestHeader() call failed to complete."); }
	}

	function getRequestHeader() { UpdateFromPublicAPI(); return ""; }

	function getAllRequestHeaders() { UpdateFromPublicAPI(); return []; }	

	// Public API
	publicAPI = {
		// XHR API
		 readyState:readyState
		,responseBody:responseBody
		,responseText:responseText
		,responseXML:responseXML
		,status:status
		,statusText:statusText
		,timeout:sendTimeout
		,open:open
		,send:send
		,abort:abort
		,setRequestHeader:setRequestHeader
		,getRequestHeader:getRequestHeader
		,getAllRequestHeaders:getAllRequestHeaders
		,onreadystatechange:onreadystatechange
		,ontimeout:ontimeout

		// extended API
		,instanceId:instanceId
		,onerror:onerror
		,Configure:function(configObj) {
			if (typeof(configObj) != UNDEF && configObj != null) {
				if (configObj.instanceId != EMPTY) instanceId = configObj.instanceId;
				if (configObj.onreadystatechange != null) onreadystatechange = configObj.onreadystatechange;
				if (configObj.onerror != null) onerror = configObj.onerror;
				if (configObj.ontimeout != null) ontimeout = configObj.ontimeout;
				if (typeof(configObj.sendTimeout) != UNDEF && configObj.sendTimeout > 0) sendTimeout = configObj.sendTimeout;
				if (configObj.loadPolicyURL != EMPTY) loadPolicyURL = configObj.loadPolicyURL;
				UpdatePublicAPI();
			}
		}
		,Reset:Reset
		,Destroy:_Destructor
	};
	return publicAPI;
}

// Static Properties/Methods
flXHR.HANDLER_ERROR = 10;
flXHR.CALL_ERROR = 11;
flXHR.TIMEOUT_ERROR = 12;
flXHR.DEPENDENCY_ERROR = 13;
flXHR.PLAYER_VERSION_ERROR = 14;
flXHR.MIN_PLAYER_VERSION = "9.0.124";
flXHR.ParseXMLString = function(xmlStr) {
	var xmlDoc = null;
	if (window.ActiveXObject) {
		xmlDoc = new ActiveXObject("Microsoft.XMLDOM"); 
		xmlDoc.async=false;
		xmlDoc.loadXML(xmlStr);
	}
	else {
		var parser = new DOMParser();
		xmlDoc = parser.parseFromString(xmlStr,"text/xml");
	}
	return xmlDoc;
}
flXHR.GetObjectById = function(idStr) {
	try {
		if (document.layers)  return document.layers[idStr];
		else if (document.all) return document.all[idStr];
		else if (document.getElementById) return document.getElementById(idStr);
	}
	catch (err) { }
	return null;
}
flXHR.BindEvent = function(obj,eventName,handlerFunc) {
	eventName = eventName.toLowerCase();
	if (typeof(obj.addEventListener) != "undefined") obj.addEventListener(eventName.replace(/^on/,""),handlerFunc,false);
	else if (typeof(obj.attachEvent) != "undefined") obj.attachEvent(eventName,handlerFunc);
	else if (typeof(obj[eventName]) == "function") {
		var oldHandler = obj[eventName];
		obj[eventName] = function() {
			oldHandler();
			handlerFunc();
		};
	}
	else obj[eventName] = handlerFunc;
}
flXHR.BinaryToString = function(binobj) {
	try { return flXHR_vb_BinaryToString(binobj); }
	catch (err) {
		var str = "";
		try { for (var i=0; i<binobj.length; i++) str += String.fromCharCode(binobj[i]); } catch (err2) { str += " "; }
		return str;
	}
}
flXHR.ArrayToBinary = function(byteArray) {
	var str = "";
	for (var i=0; i<byteArray.length; i++) {
		try { str += String.fromCharCode(byteArray[i]); } catch (err) { }
	}
	try { return flXHR_vb_StringToBinary(str); } catch (err) { }
	return byteArray;
}
flXHR.ThrowUnhandledError = function(errDescription) {
	throw new Error(errDescription);
}
flXHR.Error = function(code,name,description,srcElement) {
	return {
		 number:code
		,name:name
		,description:description
		,message:description
		,srcElement:srcElement
		,toString:function() { return number+", "+name+", "+description; }
	};
}
